<?php
	include "langsettings.php";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta name="author" content="Kai Oswald Seidler, Kay Vogelgesang, Carsten Wiedmann">
		<link href="xampp.css" rel="stylesheet" type="text/css">
		<title></title>
	</head>

	<body>
		&nbsp;<br>
	<h1><?php print $TEXT['start-head']; ?>!</h1>
	<b><?php print $TEXT['start-subhead']; ?></b><p><p>

	<b>++++ ++++ <i>A great thank you to hackattack142 for this new fine Control Panel!</i> ++++ ++++</b><p> 
	<img src="img/xampp-site-and-control-panel.jpg" alt="New Control Panel" /><p><p>
	<?php print $TEXT['start-text1']; ?><p>
	<?php print $TEXT['start-text2']; ?><p>
	<?php print $TEXT['start-text3']; ?><p>
	<?php print $TEXT['start-text4']; ?><p>
	<?php print $TEXT['start-text6']; ?><p>
	


	</body>
</html>
