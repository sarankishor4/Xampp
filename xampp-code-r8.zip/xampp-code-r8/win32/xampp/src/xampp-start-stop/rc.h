#ifndef _RC_H_INCLUDED
#define _RC_H_INCLUDED

#define XAMPP_ICON		          300


#endif // _RC_H_INCLUDED
