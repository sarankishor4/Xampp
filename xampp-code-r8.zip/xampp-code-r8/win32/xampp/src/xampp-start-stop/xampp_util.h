// Copyright (C) 2007-2010 Kai Seidler, oswald@apachefriends.org, GPL-licensed

void xampp_call(char *start[10][10]);
void xampp_cdx();
